import React from 'react';
import PropTypes from 'prop-types';

// Import des composant depuis semantic ui
import { Form, Input} from 'semantic-ui-react';

const SearchBar = ({ searchInputValue, setSearchInputValue, Submit }) => (
  <Form onSubmit={(event) => {
    event.preventDefault();
    Submit();
  }}
  >
      <Input
        onChange={(event) => {
          setSearchInputValue(event.target.value);
        }}
        value={searchInputValue}
        placeholder="Saissisez votre recherche"
      />
  </Form>
);

SearchBar.propTypes = {
  searchInputValue: PropTypes.string.isRequired,
  setSearchInputValue: PropTypes.func.isRequired,
  Submit: PropTypes.func.isRequired,
};

export default SearchBar;
